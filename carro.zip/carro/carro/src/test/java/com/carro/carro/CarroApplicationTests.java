package com.carro.carro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarroApplicationTests {

	@Test
	void contextLoads() {
	}

}
